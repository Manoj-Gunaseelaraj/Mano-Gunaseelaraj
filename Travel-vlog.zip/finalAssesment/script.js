const nav_button= document.querySelector(".btn-mobile-nav");
const nav = document.querySelector(".nav-lists");

nav_button.addEventListener("click",function(e){
   
    nav_button.classList.add(nav)
})